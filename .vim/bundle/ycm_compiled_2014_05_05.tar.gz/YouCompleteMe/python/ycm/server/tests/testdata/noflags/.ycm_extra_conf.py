def FlagsForFile( filename ):
  return {
    'flags': [],
    'do_cache': True
  }

