using System;
using System.Collections.Generic;
using System.Linq;

namespace OmniSharp.Configuration
{
    public enum PathMode
    {
        Windows,
        Unix,
        Cygwin,
    }
}
