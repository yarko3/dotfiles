﻿namespace OmniSharp.GotoImplementation
{
    public class Location
    {
        public string FileName { get; set; }
        public int Line { get; set; }
        public int Column { get; set; }
    }
}