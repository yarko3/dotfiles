﻿using OmniSharp.Common;

namespace OmniSharp.Rename
{
    public class RenameRequest : Request
    {
        public string RenameTo { get; set; }
    }
}
