﻿using OmniSharp.Common;

namespace OmniSharp.ProjectManipulation.RemoveFromProject
{
    public class RemoveFromProjectRequest : Request
    {
    }
}
