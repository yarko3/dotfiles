﻿namespace OmniSharp.CodeActions
{
    public class RunCodeActionsResponse
    {
        public string Text { get; set; }
    }
}