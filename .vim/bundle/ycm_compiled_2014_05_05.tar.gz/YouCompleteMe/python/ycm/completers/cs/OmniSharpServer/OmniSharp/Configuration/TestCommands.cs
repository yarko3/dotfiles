﻿namespace OmniSharp.Configuration
{
    public class TestCommands
    {
        public string All { get; set; }
        public string Fixture { get; set; }
        public string Single { get; set; }
    }
}