""" needed for some modules to test against packages. """

some_variable = 1
