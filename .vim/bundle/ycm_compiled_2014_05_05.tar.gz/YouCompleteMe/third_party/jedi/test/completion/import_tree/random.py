"""
Here because random is also a builtin module.
"""
a = set
